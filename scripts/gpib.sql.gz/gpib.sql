-- MySQL dump 10.13  Distrib 5.7.28, for Linux (x86_64)
--
-- Host: localhost    Database: gpib
-- ------------------------------------------------------
-- Server version	5.7.28-0ubuntu0.18.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `DEVICE_DOCUMENTATION`
--

DROP TABLE IF EXISTS `DEVICE_DOCUMENTATION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DEVICE_DOCUMENTATION` (
  `DEVICE_ID` varchar(50) NOT NULL,
  `DOCUMENTATION_TYPE` varchar(30) NOT NULL,
  `URL` varchar(255) NOT NULL,
  `DOCUMENTATION_DESCRIPTION` varchar(255) NOT NULL,
  `ADDDATE` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `MODDATE` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`DEVICE_ID`,`DOCUMENTATION_TYPE`,`URL`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DEVICE_DOCUMENTATION`
--

LOCK TABLES `DEVICE_DOCUMENTATION` WRITE;
/*!40000 ALTER TABLE `DEVICE_DOCUMENTATION` DISABLE KEYS */;
INSERT INTO `DEVICE_DOCUMENTATION` VALUES ('1998','IMAGE','/assets/images/Racal_1998.jpg','Racal 1998 image','2020-01-08 17:29:29',NULL),('1998','PDF','/assets/docs/Racal--1998--user--ID7296.pdf','Racal 1998 - Operators Manual','2020-01-08 17:36:22','2020-01-08 17:49:16'),('1998','PDF','/assets/docs/Racal_1998_1999_Frequency_Counter_Maintenance_Manual.pdf','Racal 1998 - Maintenance Manual','2020-01-08 18:05:47',NULL),('3456A','IMAGE','/assets/images/SgLabs_HP 3456A.jpg','3456A image','2020-01-08 17:13:08',NULL),('3456A','PDF','/assets/docs/3456A Operators Manual Part 1 of 2.pdf','3456A Digital voltmeter - Operating manual Part 1 of 2','2020-01-08 17:56:10',NULL),('3456A','PDF','/assets/docs/3456A Operators Manual Part 2 of 2.pdf','3456A Digital voltmeter - Operating manual Part 2 of 2','2020-01-08 17:58:34',NULL),('3456A','PDF','/assets/docs/3456A-mil_calibration_manual.pdf','3456A Digital voltmeter - Calibration procedure','2020-01-08 18:01:14',NULL),('3456A','PDF','/assets/docs/3456a_op_and_service_high_res.pdf','3456A Digital voltmeter - Operating and Service Manual','2020-01-08 18:07:39',NULL),('3456A','PDF','/assets/gpib-user-tutorial.pdf','GPIB tutorial - User','2020-01-08 16:13:18',NULL);
/*!40000 ALTER TABLE `DEVICE_DOCUMENTATION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DEVICE_FUNCTION`
--

DROP TABLE IF EXISTS `DEVICE_FUNCTION`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DEVICE_FUNCTION` (
  `DEVICE_ID` varchar(50) NOT NULL,
  `COMMAND_GROUP` varchar(50) NOT NULL,
  `COMMAND_ID` varchar(50) NOT NULL,
  `COMMAND_DESCRIPTION` varchar(80) NOT NULL,
  `DEVICE_CODE` varchar(50) NOT NULL,
  `ADDDATE` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `MODDATE` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`DEVICE_ID`,`COMMAND_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DEVICE_FUNCTION`
--

LOCK TABLES `DEVICE_FUNCTION` WRITE;
/*!40000 ALTER TABLE `DEVICE_FUNCTION` DISABLE KEYS */;
INSERT INTO `DEVICE_FUNCTION` VALUES ('1998','INPUTCNTRL','1MOHM','1 Mohm input impedance selected','AHI','2020-01-08 10:06:17',NULL),('1998','INPUTCNTRL','50OHM','50 ohm input impedance selected','ALI','2020-01-08 10:06:17',NULL),('1998','SPECIAL','BAS10CHK','Basic 10 MHz check','S70','2020-01-08 10:06:17',NULL),('1998','MEASUREMENT','CHECK','Check','CK','2020-01-08 10:06:17',NULL),('1998','MEASSCNTRL','CONTMEASMODE','Select continuous measurement mode','T0','2020-01-08 10:06:17',NULL),('1998','SPECIAL','EXTARM','External arm','S11','2020-01-08 10:06:17',NULL),('1998','MEASUREMENT','FREQA','Frequency A','FA','2020-01-08 10:06:17',NULL),('1998','MEASUREMENT','FREQB','Frequency B','FB','2020-01-08 10:06:17',NULL),('1998','SRC','INHGENMEASRDY','SRQ generated for measurement ready','Q2','2020-01-08 10:06:17',NULL),('1998','SRC','INHGENSRQ','Inhibit generation of SRQ','Q0','2020-01-08 10:06:17',NULL),('1998','SPECIAL','INTARM','Internal arm','S10','2020-01-08 10:06:17',NULL),('1998','MEASSCNTRL','NULLDIS','Null disabled','ND','2020-01-08 10:06:17',NULL),('1998','MEASSCNTRL','NULLEN','Null enabled','NE','2020-01-08 10:06:17',NULL),('1998','MEASSCNTRL','ONEMEASMODE','Select one-shot measurement mode','T1','2020-01-08 10:06:17',NULL),('1998','MEASUREMENT','PERIODA','Period A','PA','2020-01-08 10:06:17',NULL),('1998','INPUTCNTRL','POSPULSE','Pos. pulse offset (M/S ratio less than 1:2:5) selected','APS','2020-01-08 10:06:17',NULL),('1998','PRESET','PRESET','Inst. functions and settings to power-up state','CK','2020-01-08 10:06:17',NULL),('1998','MEASUREMENT','RATIOAD','Ratio A/D','RA','2020-01-08 10:06:17',NULL),('1998','MEASUREMENT','RATIOBA','Ratio B/A','RB','2020-01-08 10:06:17',NULL),('1998','STORERECALL','RECDISRES','Recall display resolution number','RRS','2020-01-08 10:06:17',NULL),('1998','STORERECALL','RECUNITTYPE','Recall unit type','RUT','2020-01-08 10:06:17',NULL),('1998','MEASSCNTRL','RESET','Stop measurement cycle and clear output buffer','RE','2020-01-08 10:06:17',NULL),('1998','INPUTCNTRL','SINWAVE','Sinewave offset (M/S ratio between 1:2.5 and 2.5:1) selected','ASS','2020-01-08 10:06:17',NULL),('1998','SRC','SRQGENERR','SRQ generated when error is detected','Q1','2020-01-08 10:06:17',NULL),('1998','STORERECALL','STOREDISRES','Store display resolution number','SRS','2020-01-08 10:06:17',NULL),('1998','STORERECALL','STORENULL','Store null value','SN','2020-01-08 10:06:17',NULL),('1998','MEASSCNTRL','TAKEONEMEAS','Take one measurement','T2','2020-01-08 10:06:17',NULL),('3456A','FUNCTION','ACV','Function AC volt','F2','2019-12-30 12:21:23',NULL),('3456A','FUNCTION','ACV+DCV','Function AC+DC volt','F3','2019-12-30 12:21:23',NULL),('3456A','FUNCTION','DCV','Function DC volt','F1','2019-12-30 12:21:23',NULL),('3456A','MATH','MATH-OFF','Set Math off','M0','2019-12-30 12:21:23',NULL),('3456A','FUNCTION','SHIFT','Shift off','S0','2019-12-30 12:21:23',NULL),('3456A','TEST','TEST-OFF','Test Off','TE0','2019-12-30 12:21:23',NULL),('3456A','TEST','TEST-ON','Test On','TE1','2019-12-30 12:21:23',NULL),('3456A','TRIGGER','TRG-EXT','Trigger External','T2','2019-12-30 12:21:23',NULL),('3456A','TRIGGER','TRG-HOLD','Trigger Hold','T4','2019-12-30 12:21:23',NULL),('3456A','TRIGGER','TRG-INT','Trigger External','T1','2019-12-30 12:21:23',NULL),('3456A','TRIGGER','TRG-SINGLE','Trigger Single','T3','2019-12-30 12:21:23',NULL);
/*!40000 ALTER TABLE `DEVICE_FUNCTION` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `GPIB_DEVICE`
--

DROP TABLE IF EXISTS `GPIB_DEVICE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `GPIB_DEVICE` (
  `DEVICE_ID` varchar(50) NOT NULL,
  `DESCRIPTION` varchar(80) NOT NULL,
  `MINOR` int(11) NOT NULL DEFAULT '0',
  `PAD` int(11) NOT NULL,
  `SAD` int(11) NOT NULL DEFAULT '0',
  `TIMEOUT` int(11) NOT NULL DEFAULT '10',
  `SEND_EOI` int(11) NOT NULL DEFAULT '1',
  `EOS_MODE` int(11) NOT NULL DEFAULT '0',
  `ADDDATE` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `MODDATE` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`DEVICE_ID`),
  UNIQUE KEY `PAD` (`PAD`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `GPIB_DEVICE`
--

LOCK TABLES `GPIB_DEVICE` WRITE;
/*!40000 ALTER TABLE `GPIB_DEVICE` DISABLE KEYS */;
INSERT INTO `GPIB_DEVICE` VALUES ('1998','Racal 1998',0,15,0,10,1,0,'2020-01-08 09:37:54',NULL),('3456A','HP - Digital Voltmeter',0,22,0,10,1,0,'2019-12-29 20:27:05',NULL);
/*!40000 ALTER TABLE `GPIB_DEVICE` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-01-08 18:13:49
